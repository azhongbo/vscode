#!/usr/bin/python3
import os,time,datetime,time,re
from tkinter import *
import tkinter as tk
import requests, time


window = Tk()
window.title( "遠端會議連線")
window.geometry('560x280')


def getData_4_listbox1():
    global listbox1, label3Text

    myTime = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time() + 0 * 24 * 60 * 60 ) )

    listbox1.delete(0,tk.END)

    data = {'func': 'list'}   
    for roomInfo in requests.post('http://192.168.5.106/help/uvnc/postData.php', data=data).text.split("\n"):
        if len(roomInfo) > 0:
            listbox1.insert(END, roomInfo )

    label3Text.set(f"會議室列表讀取完成 {myTime}")



def vnc2meetingRoom(roomID):
    global label3Text, textBox1

    errFlag = ""
    passwd = textBox1.get("1.0","end").strip()  ## 讀取驗證碼

    if len(passwd) < 6: errFlag = "錯誤: 驗證碼須輸入6碼"
    if len(roomID) < 2: errFlag = "錯誤: 未選擇會議室"

    if len(errFlag) > 2:
        label3Text.set(errFlag)

    else:
        passwd = str(int(passwd)*int(passwd))[:6]
        roomID = roomID.strip()[:6]

        data = {'func':'getIP', 'roomID':roomID }   
        addrIp = requests.post('http://192.168.5.106/help/uvnc/postData.php', data=data).text.strip()

        label3Text.set(f"正在連接: {roomID}")

        command = f"meeting.sh {passwd} {addrIp}"
        os.system(command)
        
        # with os.popen(command) as myCommand:
        #     dataArray = myCommand.readlines()
        #     for data in dataArray:
        #         print(data)

left = 20
top  = 20

label1   = tk.Label(window, text = "請選擇會議室: ", font=("Arial",12), fg="black").place(x=left, y=top)

top = top + 30
listbox1 = tk.Listbox(window, width=30, height=8, font=("Ubuntu",16), fg="black" )
listbox1.place(x=left,y=top)
# getData_4_listbox1()
# listbox1.insert(END,"00231 會議室1")
# listbox1.insert(END,"00232 會議室2")
# listbox1.insert(END,"00233 會議室3")
# listbox1.insert(END,"00233 會議室4")
# listbox1.insert(END,"00233 會議室5")
# listbox1.insert(END,"00233 會議室6")
# listbox1.insert(END,"00233 會議室7")

## 按鈕: 重新整理列表
left = left + 330
button1 =tk.Button(window, width=20, height=1 ,font=( "Ubuntu", 12) ,text="重整列表", command=lambda obj=listbox1: getData_4_listbox1()  ).place(x=left, y=top)


top = top + 80
label2   = tk.Label(window, text = "請輸入 驗證碼: ", font=("Arial",12), fg="black").place(x=left, y=top)


top = top + 25
textBox1 = tk.Text(window, width=15, height=1, font=("Arial",18), fg="black" ,  )
textBox1.place(x=left,y=top)


## 按鈕:  參加會議
top = top + 35
button2 =tk.Button(window, width=20, height=1 ,font=( "Ubuntu", 12) ,text="參加會議", command=lambda obj=listbox1: vnc2meetingRoom( obj.get(ANCHOR) )  ).place(x=left, y=top)

left = 20
top = top + 45
label3Text = tk.StringVar()
label3     = tk.Label(window, text = "目前狀態: ", font=("Arial",12), fg="black", textvariable=label3Text   ).place(x=left, y=top)


getData_4_listbox1() ## 載入會議室列表




window.mainloop()
