#!/bin/bash
# echo $1
# vncpasswd -f <<< 152413 > ~/.vnc/passwd

vncviewer -passwd <(echo $1 | vncpasswd -f) $2:5966

